<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DailyMission extends Model
{
    //
}
